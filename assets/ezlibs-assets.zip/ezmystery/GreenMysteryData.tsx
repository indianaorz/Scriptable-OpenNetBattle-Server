<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="GreenMysteryData" tilewidth="14" tileheight="43" tilecount="8" columns="8" objectalignment="bottom">
 <tileoffset x="0" y="3"/>
 <image source="GreenMysteryData.png" width="112" height="43"/>
 <tile id="0">
  <objectgroup draworder="index" id="4">
   <object id="6" x="-1.18582" y="35.7723" width="16.4533" height="9.33835">
    <ellipse/>
   </object>
  </objectgroup>
  <animation>
   <frame tileid="0" duration="100"/>
   <frame tileid="1" duration="100"/>
   <frame tileid="2" duration="100"/>
   <frame tileid="3" duration="100"/>
   <frame tileid="4" duration="100"/>
   <frame tileid="5" duration="100"/>
   <frame tileid="6" duration="100"/>
   <frame tileid="7" duration="100"/>
  </animation>
 </tile>
</tileset>
