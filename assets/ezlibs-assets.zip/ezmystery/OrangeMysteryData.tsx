<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.5.0" name="OrangeMysteryData" tilewidth="14" tileheight="43" tilecount="8" columns="8" objectalignment="bottom">
 <tileoffset x="0" y="3"/>
 <image source="OrangeMysteryData.png" width="112" height="43"/>
 <tile id="0">
  <objectgroup draworder="index" id="4">
   <object id="6" x="-1.18582" y="35.7723" width="16.4533" height="9.33835">
    <ellipse/>
   </object>
  </objectgroup>
  <animation>
   <frame tileid="0" duration="100"/>
   <frame tileid="1" duration="100"/>
   <frame tileid="2" duration="100"/>
   <frame tileid="3" duration="100"/>
   <frame tileid="4" duration="100"/>
   <frame tileid="5" duration="100"/>
   <frame tileid="6" duration="100"/>
   <frame tileid="7" duration="100"/>
  </animation>
 </tile>
 <tile id="1">
  <objectgroup draworder="index" id="2">
   <object id="1" x="1" y="38" width="12" height="5">
    <ellipse/>
   </object>
  </objectgroup>
 </tile>
 <tile id="2">
  <objectgroup draworder="index" id="2">
   <object id="1" x="1" y="38" width="12" height="5">
    <ellipse/>
   </object>
  </objectgroup>
 </tile>
 <tile id="3">
  <objectgroup draworder="index" id="2">
   <object id="1" x="1" y="38" width="12" height="5">
    <ellipse/>
   </object>
  </objectgroup>
 </tile>
 <tile id="4">
  <objectgroup draworder="index" id="2">
   <object id="1" x="1" y="38" width="12" height="5">
    <ellipse/>
   </object>
  </objectgroup>
 </tile>
 <tile id="5">
  <objectgroup draworder="index" id="2">
   <object id="1" x="1" y="38" width="12" height="5">
    <ellipse/>
   </object>
  </objectgroup>
 </tile>
 <tile id="6">
  <objectgroup draworder="index" id="2">
   <object id="1" x="1" y="38" width="12" height="5">
    <ellipse/>
   </object>
  </objectgroup>
 </tile>
 <tile id="7">
  <objectgroup draworder="index" id="2">
   <object id="1" x="1" y="38" width="12" height="5">
    <ellipse/>
   </object>
  </objectgroup>
 </tile>
</tileset>
