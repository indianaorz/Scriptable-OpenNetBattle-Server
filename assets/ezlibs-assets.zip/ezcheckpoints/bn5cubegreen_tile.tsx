<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.9.2" name="bn5cubegreen" tilewidth="42" tileheight="44" tilecount="4" columns="4">
 <tileoffset x="0" y="11"/>
 <image source="bn5cubegreen_tile.png" width="168" height="44"/>
 <tile id="0">
  <objectgroup draworder="index" id="2">
   <object id="2" x="-6" y="34">
    <polygon points="0,0 27.1463,-14 53,0 27.1463,14"/>
   </object>
  </objectgroup>
  <animation>
   <frame tileid="0" duration="133"/>
   <frame tileid="1" duration="100"/>
   <frame tileid="2" duration="133"/>
   <frame tileid="3" duration="100"/>
  </animation>
 </tile>
</tileset>
