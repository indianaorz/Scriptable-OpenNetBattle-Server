<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.9.2" name="plants.png" tilewidth="23" tileheight="55" tilecount="210" columns="7" objectalignment="bottom">
 <tileoffset x="0" y="27"/>
 <image source="plants.png" width="161" height="1650"/>
</tileset>
