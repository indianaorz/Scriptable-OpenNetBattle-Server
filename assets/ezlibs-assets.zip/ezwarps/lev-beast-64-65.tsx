<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.5.0" name="lev-beast-64-65" tilewidth="64" tileheight="65" tilecount="3" columns="3">
 <image source="lev-beast-64-65.png" width="192" height="65"/>
 <tile id="0">
  <animation>
   <frame tileid="0" duration="1000"/>
   <frame tileid="1" duration="1000"/>
   <frame tileid="2" duration="1000"/>
   <frame tileid="1" duration="1000"/>
  </animation>
 </tile>
</tileset>
