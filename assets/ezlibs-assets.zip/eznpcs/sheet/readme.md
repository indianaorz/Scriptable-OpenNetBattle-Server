The .json files are project files compatible with
https://github.com/Keristero/spritesheet-tool
which can be used to generate the packed .png files and .animation files