-- jumping_enemy.lua
-- Defines an enemy that jumps to a random tile on its side every second,
-- structured similarly to the provided example and using Canodumb assets.

-- A no-operation function, useful for default event handlers.
local noop = function () end

-- Asset paths (assuming _folderpath is provided by the game engine and points to the mod's asset directory)
-- These will be loaded in package_init.
local CANODUMB_TEXTURE_PATH = _folderpath .. "essenceghost.png"
local CANODUMB_ANIMATION_PATH = _folderpath .. "essenceghost.animation"
local JUMP_SFX_PATH = _folderpath .. "cannon.ogg" -- Using Canodumb's cannon sound for jump

-- Loaded assets (will be populated in package_init if not already loaded globally or per instance)
local g_canodumb_texture = nil
local g_jump_sfx = nil
-- Note: Animation path is usually loaded per instance via anim:load(path)

--- Moves the enemy to a random tile on its own side of the field.
---@param self Entity The enemy instance.
local function move_to_random_friendly_tile(self)
    local field = self:get_field()
    if not field then
        -- Log.warning(self:get_name() .. ": Field not found for jumping.")
        return false
    end

    local team_id = self:get_team()
    local team_tiles = field:get_tiles(team_id)

    if team_tiles and #team_tiles > 0 then
        local random_index = math.random(#team_tiles)
        local target_tile = team_tiles[random_index]

        if target_tile then
            self:teleport_to_tile(target_tile) -- Using teleport for direct movement
            return true
        else
            -- Log.warning(self:get_name() .. ": Target tile was nil after random selection.")
            return false
        end
    else
        -- Log.info(self:get_name() .. ": No team tiles found to jump to for team " .. tostring(team_id))
        return false
    end
end

--- Main update function for the JumpingEnemy.
--- Called every frame by the game engine.
---@param self Entity The enemy instance.
---@param dt number Delta time (not explicitly used here as logic is frame-based).
local function jumping_enemy_update(self, dt)
    self.frame_counter = self.frame_counter + 1

    if self.frame_counter >= self.jump_interval_frames then
        self.frame_counter = 0 -- Reset counter

        -- Play jump sound effect
        if g_jump_sfx then
            Engine.play_audio(g_jump_sfx, AudioPriority.Low)
        end

        -- Move the enemy immediately
        move_to_random_friendly_tile(self)
            
        -- Ensure animation returns to/stays in idle state
        local anim = self.animation -- Access stored animation controller
        if anim:get_current_state_name() ~= self.idle_anim_state or anim:get_playback() ~= Playback.Loop then
            anim:set_state(self.idle_anim_state)
            anim:set_playback(Playback.Loop)
            anim:on_complete(nil) -- Clear any previous on_complete callback
        end
    end
end

--- Initializes the JumpingEnemy instance.
---@param self Entity The enemy instance.
---@param character_info table Optional table with character data (not used in this version).
function package_init(self, character_info)
    -- Load assets once
    if not g_canodumb_texture then
        g_canodumb_texture = Engine.load_texture(CANODUMB_TEXTURE_PATH)
    end
    if not g_jump_sfx then
        g_jump_sfx = Engine.load_audio(JUMP_SFX_PATH)
    end

    -- Common Properties
    self:set_name("JumpingEnemy")
    self:set_health(50) -- Example health
    self:set_height(55) -- Using Canodumb's height
    self:set_element(Element.None) -- Or specify an element

    -- Texture and Animation
    if g_canodumb_texture then
        self:set_texture(g_canodumb_texture)
    end
    self.animation = self:get_animation() -- Get the animation controller attached to this entity
    self.animation:load(CANODUMB_ANIMATION_PATH) -- Load Canodumb's animations

    -- JumpingEnemy Specific Properties
    self.jump_interval_frames = 60 -- Approx 1 second at 60 FPS
    self.frame_counter = 0
    self.idle_anim_state = "IDLE"       -- From Canodumb
    -- self.action_anim_state = "SHOOT_1" -- Removed: No specific action animation for jump to avoid "shoot" appearance

    -- Set initial animation state
    self.animation:set_state(self.idle_anim_state)
    self.animation:set_playback(Playback.Loop)

    -- Defense
    self.defense = Battle.DefenseVirusBody.new()
    self:add_defense_rule(self.defense)

    -- Assign event handlers
    self.update_func = jumping_enemy_update
    
    self.battle_start_func = function(enemy_instance)
        enemy_instance.frame_counter = 0 -- Reset on battle start
    end

    self.on_spawn_func = function(enemy_instance)
        -- Randomize initial timer slightly to desynchronize multiple instances
        enemy_instance.frame_counter = math.random(0, enemy_instance.jump_interval_frames -1)
        -- Ensure animation is correctly set on spawn
        if enemy_instance.animation:get_current_state_name() ~= enemy_instance.idle_anim_state then
            enemy_instance.animation:set_state(enemy_instance.idle_anim_state)
            enemy_instance.animation:set_playback(Playback.Loop)
        end
    end
    
    self.battle_end_func = noop
    self.delete_func = noop

    -- Log.info("JumpingEnemy (new structure) initialized: " .. self:get_name())
end

return package_init
