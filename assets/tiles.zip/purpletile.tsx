<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="purpletile" tilewidth="64" tileheight="156" tilecount="1" columns="1">
 <tileoffset x="0" y="128"/>
 <image source="purpletile.png" width="64" height="156"/>
</tileset>
