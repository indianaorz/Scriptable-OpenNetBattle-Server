<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="hp_warp" tilewidth="114" tileheight="64" tilecount="5" columns="5" objectalignment="top">
 <image source="hp_warp.png" width="570" height="64"/>
 <tile id="1">
  <objectgroup draworder="index" id="2">
   <object id="1" x="37" y="16" width="40" height="25">
    <ellipse/>
   </object>
  </objectgroup>
  <animation>
   <frame tileid="1" duration="100"/>
   <frame tileid="2" duration="100"/>
   <frame tileid="3" duration="100"/>
   <frame tileid="4" duration="100"/>
  </animation>
 </tile>
</tileset>
