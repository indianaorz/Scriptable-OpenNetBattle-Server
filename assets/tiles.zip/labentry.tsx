<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="labentry" tilewidth="1252" tileheight="847" tilecount="1" columns="1">
 <tileoffset x="0" y="847"/>
 <image source="labentry.png" width="1252" height="847"/>
</tileset>
