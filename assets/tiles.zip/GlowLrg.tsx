<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="GlowLrg" tilewidth="64" tileheight="41" tilecount="3" columns="1">
 <tileoffset x="0" y="11"/>
 <image source="GlowLrg.png" width="64" height="123"/>
</tileset>
