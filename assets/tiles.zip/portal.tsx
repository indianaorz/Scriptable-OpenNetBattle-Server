<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="portal" tilewidth="300" tileheight="292" tilecount="1" columns="1">
 <tileoffset x="11" y="16"/>
 <image source="portal.png" width="300" height="292"/>
</tileset>
