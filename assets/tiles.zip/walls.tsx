<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="walls" tilewidth="64" tileheight="109" tilecount="1" columns="1">
 <tileoffset x="0" y="64"/>
 <grid orientation="orthogonal" width="62" height="109"/>
 <image source="walls.png" width="64" height="109"/>
</tileset>
