<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.6" name="rocksbridge" tilewidth="655" tileheight="386" tilecount="1" columns="1">
 <image source="rocksbridge.png" width="655" height="386"/>
</tileset>
