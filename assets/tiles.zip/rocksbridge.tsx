<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="rocksbridge" tilewidth="655" tileheight="653" tilecount="1" columns="1">
 <grid orientation="orthogonal" width="655" height="386"/>
 <image source="rocksbridge.png" width="655" height="653"/>
</tileset>
