<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="portalfront" tilewidth="84" tileheight="104" tilecount="1" columns="1" objectalignment="center">
 <image source="portalfront.png" width="84" height="104"/>
</tileset>
