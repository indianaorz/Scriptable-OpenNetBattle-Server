<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="block" tilewidth="62" tileheight="72" tilecount="8" columns="8">
 <tileoffset x="0" y="15"/>
 <image source="block.png" width="511" height="72"/>
</tileset>
