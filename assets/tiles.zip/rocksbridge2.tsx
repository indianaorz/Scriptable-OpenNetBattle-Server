<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="rocksbridge2" tilewidth="735" tileheight="397" tilecount="1" columns="1">
 <image source="rocksbridge2.png" width="735" height="397"/>
</tileset>
