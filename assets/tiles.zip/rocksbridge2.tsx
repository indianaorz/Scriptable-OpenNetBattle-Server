<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="rocksbridge2" tilewidth="683" tileheight="309" tilecount="1" columns="1">
 <image source="rocksbridge2.png" width="683" height="309"/>
</tileset>
