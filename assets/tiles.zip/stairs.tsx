<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.1" name="stairs" tilewidth="64" tileheight="56" tilecount="3" columns="3">
 <tileoffset x="-3" y="9"/>
 <image source="stairs.png" width="192" height="56"/>
 <tile id="0" type="Stairs">
  <properties>
   <property name="Direction" value="Up Left"/>
  </properties>
 </tile>
 <tile id="1" type="Stairs">
  <properties>
   <property name="Direction" value="Up Left"/>
  </properties>
 </tile>
</tileset>
