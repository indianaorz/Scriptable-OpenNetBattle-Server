<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="home_warp" tilewidth="60" tileheight="32" tilecount="5" columns="5" objectalignment="top">
 <image source="home_warp.png" width="300" height="32"/>
 <tile id="0">
  <objectgroup draworder="index" id="2">
   <object id="1" x="3" y="1" width="52" height="30">
    <ellipse/>
   </object>
  </objectgroup>
  <animation>
   <frame tileid="0" duration="50"/>
   <frame tileid="1" duration="50"/>
   <frame tileid="2" duration="50"/>
   <frame tileid="3" duration="50"/>
   <frame tileid="4" duration="50"/>
   <frame tileid="3" duration="50"/>
   <frame tileid="2" duration="50"/>
   <frame tileid="1" duration="50"/>
  </animation>
 </tile>
</tileset>
