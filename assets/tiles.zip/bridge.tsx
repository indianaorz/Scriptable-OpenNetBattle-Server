<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.6" name="bridge" tilewidth="1272" tileheight="632" tilecount="1" columns="1">
 <image source="bridge.png" width="1272" height="632"/>
</tileset>
