<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="bridge" tilewidth="1618" tileheight="967" tilecount="1" columns="1">
 <tileoffset x="0" y="840"/>
 <grid orientation="orthogonal" width="1618" height="840"/>
 <image source="bridge.png" width="1618" height="967"/>
</tileset>
