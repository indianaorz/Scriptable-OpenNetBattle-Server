<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.1" name="cloud" tilewidth="92" tileheight="51" tilecount="12" columns="12">
 <tileoffset x="-14" y="16"/>
 <image source="cloud.png" width="1104" height="51"/>
 <tile id="5">
  <objectgroup draworder="index" id="2">
   <object id="1" x="78" y="-1">
    <polygon points="4,22 -28,38 -64,20 -32,4"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="6">
  <objectgroup draworder="index" id="2">
   <object id="1" x="78" y="-1">
    <polygon points="4,22 -28,38 -64,20 -32,4"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="7">
  <objectgroup draworder="index" id="2">
   <object id="1" x="78" y="-1">
    <polygon points="0,20 -32,36 -64,20 -32,4"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="8">
  <objectgroup draworder="index" id="2">
   <object id="1" x="78" y="-1">
    <polygon points="0,20 -32,36 -64,20 -32,4"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="9">
  <objectgroup draworder="index" id="2">
   <object id="1" x="78" y="-1">
    <polygon points="0,20 -32,36 -64,20 -32,4"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="10">
  <objectgroup draworder="index" id="2">
   <object id="1" x="78" y="-1">
    <polygon points="0,20 -32,36 -64,20 -32,4"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="11">
  <objectgroup draworder="index" id="2">
   <object id="1" x="78" y="-1">
    <polygon points="0,20 -32,36 -64,20 -32,4"/>
   </object>
  </objectgroup>
 </tile>
</tileset>
