<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="floor" tilewidth="62" tileheight="49" tilecount="8" columns="8">
 <tileoffset x="0" y="17"/>
 <image source="floor.png" width="511" height="49"/>
</tileset>
