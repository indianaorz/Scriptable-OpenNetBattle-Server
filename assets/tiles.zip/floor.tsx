<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.1" name="floor" tilewidth="62" tileheight="49" tilecount="3" columns="3" objectalignment="bottom">
 <tileoffset x="0" y="17"/>
 <grid orientation="isometric" width="62" height="49"/>
 <image source="floor.png" width="186" height="49"/>
</tileset>
