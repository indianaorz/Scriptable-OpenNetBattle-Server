<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="lab_assets" tilewidth="96" tileheight="128" tilecount="1" columns="1" objectalignment="bottom">
 <tileoffset x="0" y="37"/>
 <image source="lab_assets.png" width="96" height="128"/>
 <tile id="0">
  <objectgroup draworder="index" id="2">
   <object id="1" x="9.62945" y="90.97">
    <polygon points="0,0 39.5374,-20.7316 78.5084,-0.793014 40.1038,19.0323"/>
   </object>
  </objectgroup>
 </tile>
</tileset>
